library(testthat)
library(PCMBase)

test_check("PCMBaseCpp")
